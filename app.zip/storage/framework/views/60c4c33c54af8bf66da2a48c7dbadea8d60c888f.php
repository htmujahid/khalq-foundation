<div class="relative h-[450px] w-[350px] sm:w-[400px] overflow-hidden rounded-3xl bg-white pt-4 ring-1 ring-gray-900/5">
  <div class="text-center text-xl font-bold">KHALQ Foundation Pakistan</div>
  <div class="mx-auto my-2 w-fit font-bold">
    <div class="rounded-full border py-1 px-2">Case # <?php echo e($id); ?></div>
  </div>
  <p class="hide-scrollbar h-[140px] overflow-y-scroll px-6 text-justify text-sm"><?php echo e($description); ?></p>
  <p class="mt-2 px-6 text-justify text-sm">For Details Please Contact: 0315-4381490</p>
  <div class="my-1 flex justify-between px-6 text-center text-sm font-semibold">
    <div class="w-full rounded-l-full border">Required <span class="block"><?php echo e((int)($required)); ?></span></div>
    <div class="w-full border">Collected <span class="block"><?php echo e((int)($collected)); ?></span></div>
    <div class="w-full rounded-r-full border">Remaining <span class="block"><?php echo e((int)($remaining)); ?></span></div>
  </div>
  <div class="bg-red-600 py-1 text-center text-lg font-bold text-white">FOR DONATIONS</div>
  <div class="relative bg-primary px-6 pt-3 pb-5 text-white">
      <div class="hide-scrollbar overflow-x-auto unselectable flex justify-between gap-3">
          <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>        
              <div class="shrink-0 text-center">
                  <div class="mx-auto w-full rounded-full bg-white border border-white py-1 px-2">
                      <img src="/assets/images/accounts/<?php echo e(strtolower($account->bank_name)); ?>.png" alt="" class="h-5 mx-auto">
                  </div>
                  <p class="mt-1 h-4 overflow-hidden text-xs"><?php echo e($account->account_name); ?></p>
                  <p class="text-sm"><?php echo e($account->account_number); ?></p>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              No Account Information Available
          <?php endif; ?>
      </div>
  </div>
</div><?php /**PATH D:\Projects\khalq\khalqfoundation.org\resources\views/components/card/case.blade.php ENDPATH**/ ?>