<div class="text-center user-select-none">
    <p class="small m-0">
        KHALQ Foundation Admin Panel
    </p>
</div>
<?php /**PATH D:\Projects\khalq\khalqfoundation_admin\resources\views/brand/footer.blade.php ENDPATH**/ ?>