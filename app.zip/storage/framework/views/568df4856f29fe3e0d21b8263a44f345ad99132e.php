<div class="bg-white rounded-top shadow-sm mb-3">

    <div class="row g-0">
        <div class="col col-lg-7 mt-6 p-4">

            <h2 class="mt-2 text-dark fw-light">
                KHALQ Foundation Pakistan
            </h2>

        </div>
    </div>

    <div class="row bg-light m-0 p-md-4 p-3 border-top rounded-bottom">

        <div class="col-md-12 my-2">
            <p class="ms-md-5 ps-md-1">
                Non Profitable Charity Organization run by students.
            </p>
        </div>

        <div class="col-md-12 my-2">
            <p class="ms-md-5 ps-md-1">
                Raising the statndards of society by supporting needy people
            </p>
        </div>

        <div class="col-md-12 my-2">
            <p class="ms-md-5 ps-md-1">
                Middleware between needy people and people who are interested in charity
            </p>
        </div>

        <div class="col-md-12 my-2">
            <p class="ms-md-5 ps-md-1">
                Our Mission is to serve society by doing our part
            </p>
        </div>

    </div>

</div>

<?php /**PATH D:\Projects\khalq\khalqfoundation.org\resources\views/welcome.blade.php ENDPATH**/ ?>