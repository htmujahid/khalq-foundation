<div class="text-center user-select-none">
    <p class="small m-0">
        KHALQ Foundation Admin Panel
    </p>
</div>
<?php /**PATH /home/khalq/admin.khalqfoundation.org/resources/views/brand/footer.blade.php ENDPATH**/ ?>