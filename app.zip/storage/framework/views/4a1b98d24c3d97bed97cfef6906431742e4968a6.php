<div class="overflow-hidden relative scroll relative">
    <div id="carousel-group" class="items flex gap-4 sm:gap-8 justify-items-center overflow-x-scroll hide-scrollbar unselectable">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH D:\Projects\khalq\khalqfoundation.org\resources\views/components/wrapper/multicarousel.blade.php ENDPATH**/ ?>