<div class="table-notification">
    <?php echo $table; ?>

</div>
<?php /**PATH D:\Projects\khalq\admin\vendor\orchid\platform\resources\views/partials/notification-wrap.blade.php ENDPATH**/ ?>