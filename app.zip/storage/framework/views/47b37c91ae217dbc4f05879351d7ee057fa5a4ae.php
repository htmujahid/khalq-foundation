<?php echo $content; ?>


<p>Sent By: <?php echo e($sender); ?></p><?php /**PATH D:\Projects\khalq\admin\resources\views/mails/test.blade.php ENDPATH**/ ?>