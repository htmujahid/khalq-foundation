<span class="text-2xl font-bold text-<?php echo e($color ?? "white"); ?>">
    KHALQ
</span><?php /**PATH D:\Projects\khalq\khalqfoundation.org\resources\views/components/application/logo.blade.php ENDPATH**/ ?>