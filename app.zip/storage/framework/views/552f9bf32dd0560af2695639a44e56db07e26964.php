<div class="border border-black rounded-3xl">
    <a href="<?php echo e($item->link); ?>">
        <div class="h-56 w-full rounded-t-3xl overflow-hidden"><img src=<?php echo e($item->image); ?> alt=<?php echo e($item->title); ?> class="h-auto aspect-[4/3] mx-auto w-full"></div>
        <div class="color-3 rounded-b-3xl px-6 pt-6 h-40 border-t">
            <p class="text-base font-bold text-black"><?php echo e($item->title); ?></p>
            <div class="h-full pb-3 pt-1 h-24 overflow-hidden">
                <span class="h-3/6">
                    <?php echo e($item->description); ?>

                </span>
            </div>
        </div>
    </a>
</div><?php /**PATH D:\Projects\khalq\khalqfoundation.org\resources\views/components/card/project.blade.php ENDPATH**/ ?>