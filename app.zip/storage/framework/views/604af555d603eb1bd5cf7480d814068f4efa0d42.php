<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.heading.h1','data' => ['bottom' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heading.h1'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['bottom' => true]); ?>Our Impact <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="flex justify-center items-center w-full">
        
    </div>
    <div class="grid grid-cols-2 lg:grid-cols-4 sm:gap-4 align-center justify-items-center ">
        <div class="w-full sm:w-64 md:w-full bg-primary text-center h-56 rounded-tl-3xl sm:rounded-3xl shadow-1">
            <img src="/assets/icons/cases.svg" alt="" class=" inline-block mt-16 -translate-y-1/2" width="50">
            <p class="text-4xl font-bold text-white mb-2.5"><?php echo e($cases); ?>+</p>
            <p class="text-lg text-white mb-5">Cases Solved</p>
        </div>
        <div class="w-full sm:w-64 md:w-full bg-primary text-center h-56 rounded-tr-3xl sm:rounded-3xl shadow-1">
            <img src="/assets/icons/donors.svg" alt="" class=" inline-block mt-16 -translate-y-1/2">
            <p class="text-4xl font-bold text-white mb-2.5"><?php echo e($donors); ?>+</p>
            <p class="text-lg text-white mb-5">Regular Donors</p>
        </div>
        <div class="w-full sm:w-64 md:w-full bg-primary text-center h-56 rounded-bl-3xl sm:rounded-3xl shadow-1">
            <img src="/assets/icons/rate.svg" alt="" class=" inline-block mt-16 -translate-y-1/2">
            <p class="text-4xl font-bold text-white mb-2.5">100%</p>
            <p class="text-lg text-white mb-5">Cases Solving Rate</p>
        </div>
        <div class="w-full sm:w-64 md:w-full bg-primary text-center h-56 rounded-br-3xl sm:rounded-3xl shadow-1">
            <img src="/assets/icons/funds.svg" alt="" class=" inline-block mt-16 -translate-y-1/2" width="60">
            <p class="text-4xl font-bold text-white mb-2.5">Rs. <?php echo e((int) ($donations)); ?>M+</p>
            <p class="text-lg text-white mb-5">Funds Collected</p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH D:\Projects\khalq\khalqfoundation.org\resources\views/components/section/impact/index.blade.php ENDPATH**/ ?>