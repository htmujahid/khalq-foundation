<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" class="me-2" width="1em" height="1em" role="img" fill="currentColor" path="circle" componentName="orchid-icon">
    <circle cx="16" cy="16" r="16"></circle>
</svg>
<?php /**PATH /home/khalq/admin.khalqfoundation.org/storage/framework/views/82fa324f914397e5d6d60f0fccbda818b5b96af4.blade.php ENDPATH**/ ?>