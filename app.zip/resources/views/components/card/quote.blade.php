<div class="p-4 text-gray-800 bg-white rounded-lg shadow w-full sm:w-[500px] mx-auto mb-20">
    <div class="mb-2">
        <div class="h-3 text-3xl text-left text-gray-600">“</div>
        <p class="px-4 text-xl text-center text-gray-600">
        “Service to others is the rent you pay for your room here on Earth.”<br>
        ― Muhammad Ali
        </p>
        <div class="h-3 text-3xl text-gray-600 flex justify-end">”</div>
    </div>
</div>  