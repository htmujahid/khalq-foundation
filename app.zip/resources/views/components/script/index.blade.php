<script type="text/javascript">
    {!! $slot !!}
</script>