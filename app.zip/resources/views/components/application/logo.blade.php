<span class="text-2xl font-bold text-{{$color ?? "white"}}">
    KHALQ
</span>