<x-container>
    <x-heading title="Contact Details">
        Have a Question?
    </x-heading>
    <div class="flex justify-between flex-col gap-10 mt-10 mb-20">
        <x-card.contact.email email="queries@khalqfoundation.org"/>
        <x-card.contact.phone name="Syed Sadaan" phone="+92 315 4381490"/>
    </div>
</x-container>