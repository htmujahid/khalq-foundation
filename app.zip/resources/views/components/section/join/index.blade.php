<x-container topBottom='true'>
    <div class="flex items-center flex-col bg-primary-light px-10 py-10 rounded-3xl flex-shrink-0 shadow">
        <h4 class="text-2xl sm:text-3xl mb-10 text-center">Be the change you wish to see in the world and join our team today</h4>
        <x-button.primary href="">Join Us</x-button.primary>
    </div>
</x-container>