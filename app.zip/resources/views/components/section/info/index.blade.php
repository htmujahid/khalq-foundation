<x-container>
    <x-heading title="Cases">
        Donate for the Humanity
    </x-heading>
    <div class="text-xl mb-16 mt-10">
        <p>- Raise the statndards of society by supporting needy people </p>
        <p>- Donate for the needy people because every penny matters</p>
        <p>- Serve the society by doing your part</p>
    </div>
</x-container>