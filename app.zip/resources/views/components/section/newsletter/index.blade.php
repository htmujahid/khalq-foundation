<x-container topBottom='true'>
    <div class="flex items-center flex-col">
        <x-heading.h1 bottom>Subscribe to our newsletter</x-heading.h1>
        <x-heading.h4>Be the first to know our latest Compaigns!</x-heading.h4>
        <x-input.email />
    </div>
</x-container>