<!DOCTYPE html>
<html lang="en">
<x-layout.index.head/>
<body>
    <x-layout.index.nav />
    {{ $content }}
    <x-layout.index.footer />
</body>
</html>