<button>
    {{ $slot ?? 'KHALQ Admin Panel' }}
</button>