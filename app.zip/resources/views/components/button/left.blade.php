<button id="{{$id}}" {{$attributes->merge(["class" => "absolute top-1/2 -translate-y-1/2 rounded-full bg-primary hover:bg-primary-dark duration-100"])}}>
    <img src="./assets/icons/arrow.svg" alt="" class="hidden sm:block">
</button>