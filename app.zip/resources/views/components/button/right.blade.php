<button id="{{$id}}" {{$attributes->merge(["class" => "absolute top-1/2 -translate-y-1/2 right-0 rounded-full bg-primary hover:bg-primary-dark duration-100"])}}>
    <img src="./assets/icons/arrow.svg" class="rotate-180 hidden sm:block" alt="">
</button>