<h2 {{$attributes->merge(["class" => "text-4xl sm:text-5xl font-sans text-center sm:text-left"])}}>{{$slot}}</h2>
