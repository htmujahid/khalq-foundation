<h5 {{$attributes->merge(["class" => "text-xl sm:text-2xl font-sans text-center sm:text-left"])}}>{{$slot}}</h5>
