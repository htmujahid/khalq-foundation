<h4 {{$attributes->merge(["class" => "text-2xl sm:text-3xl font-sans text-center sm:text-left"])}}>{{$slot}}</h4>
