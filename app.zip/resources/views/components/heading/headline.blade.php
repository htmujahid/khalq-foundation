<p {{$attributes->merge(["class" => "text-5xl sm:text-6xl font-serif text-center lg:text-left"])}}>{{$slot}}</p>
