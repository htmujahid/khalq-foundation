<h3 {{$attributes->merge(["class" => "text-3xl sm:text-4xl font-sans text-center sm:text-left"])}}>{{$slot}}</h3>
