<h1 {{$attributes->merge(["class" => "text-5xl sm:text-6xl font-serif text-center sm:text-left mb-10"])}}>{{ $slot }}</h1>
