<p {{$attributes->merge(["class" => "text-2xl py-6 mt-10 text-center text-center sm:text-left"])}}><span class="w-6 inline-block border-t-2 border-black border-solid" ></span> {{ $slot}}</p>
<h1 {{$attributes->merge(["class" => "text-5xl sm:text-6xl font-serif text-center sm:text-left"])}}>{{ $title }}</h1>
