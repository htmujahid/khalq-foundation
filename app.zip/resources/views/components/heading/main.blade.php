<p {{$attributes->merge(["class" => "text-2xl"])}}><span class="w-6 inline-block border-t-2 border-black border-solid" ></span> {{ $slot}}</p>
