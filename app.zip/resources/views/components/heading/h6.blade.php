<h6 {{$attributes->merge(["class" => "text-lg sm:text-xl font-sans text-center sm:text-left"])}}>{{$slot}}</h6>
