<p {{$attributes->merge(["class" =>  "text-2xl sm:text-3xl mt-8 text-center lg:text-left"])}}>{{$slot}}</p>
