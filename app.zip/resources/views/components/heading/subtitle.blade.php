<h3 {{$attributes->merge(["class" =>  "text-3xl mt-4 text-center sm:text-left"])}}>{{ $slot }}</h3>
