<div {{$attributes->merge(["class" => "fixed top-0 bottom-0 left-0 right-0 bg-gray-100 bg-opacity-60 px-2d"])}}>
    {{$slot}}
</div>