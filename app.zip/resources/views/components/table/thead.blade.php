<thead {{$attributes->merge(["class" => "bg-primary-light rounded-t-lg"])}}>
    {{ $slot }}
</thead>