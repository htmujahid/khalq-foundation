{!! $content !!}

<p>Sent By: {{$sender}}</p>