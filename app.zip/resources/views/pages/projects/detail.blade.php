<x-layout>
    <x-slot name="content">
        <x-section.projects.detail project={{$project}} />
    </x-slot>
</x-layout>