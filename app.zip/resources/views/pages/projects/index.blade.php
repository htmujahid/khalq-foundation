<x-layout>
    <x-slot name="content">
        <x-section.projects />
    </x-slot>
</x-layout>