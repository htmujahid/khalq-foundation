<x-layout>
    <x-slot name="content">
        <x-section.donate />
        <x-section.contact.details />
    </x-slot>
</x-layout>