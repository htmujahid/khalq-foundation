<x-layout>
    <x-slot name="content">
        <x-section.stories />
    </x-slot>
</x-layout>