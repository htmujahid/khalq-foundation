<x-layout>
    <x-slot name="content">
        <x-section.about />
        <x-section.team/>
    </x-slot>
</x-layout>