<x-layout>
    <x-slot name="content">
        <x-section.contact.details />
        <x-section.social />
    </x-slot>
</x-layout>