<x-layout>
    <x-slot name="content">
        <x-section.hero/>
        <x-section.current/>
        <x-section.impact />
        <x-section.mission />
        <x-section.testimonial/>
        <x-section.join />
    </x-slot>
</x-layout>