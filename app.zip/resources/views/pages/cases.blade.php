<x-layout>
    <x-slot name="content">
        <x-section.info />
        <x-section.current/>
        <x-section.cases />
    </x-slot>
</x-layout>