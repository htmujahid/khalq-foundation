<x-layout>
    <x-slot name="content">
        <x-container topBottom>     
            <x-heading title="Error 404">
                Page Not Found
            </x-heading>
        </x-container>
    </x-slot>
</x-layout>