<x-layout>
    <x-slot name="content">
        <x-container topBottom>     
            <x-heading title="Error 500">
                Internal Server Error
            </x-heading>
        </x-container>
    </x-slot>
</x-layout>